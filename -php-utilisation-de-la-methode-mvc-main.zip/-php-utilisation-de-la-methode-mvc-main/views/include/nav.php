<nav class="navbar navbar-expand navbar-light bg-light">
    <div class="nav navbar-nav">
        <li class="nav-item nav-link">
            <a href="index.php?action=list" class="nav-link active">Liste des stagiaires</a>
        </li>
        <li class="nav-item nav-link">
            <a href="index.php?action=create" class="nav-link">Ajouter stagiaire</a>
        </li>
    </div>
</nav>